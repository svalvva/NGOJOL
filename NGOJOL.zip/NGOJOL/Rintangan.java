import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Rintangan here.
 * 
 * @author (Syalwa Aliya) 
 * @version (1.0)
 * ig : @syalwalyrh
 */
public class Rintangan extends Actor
{
    /**
     * Act - do whatever the Rintangan wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    public Rintangan() {
        setImage("Corong.png");
    }
    
    public void act()
    {
        // Add your action code here.
    }
}
