import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Lele here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Lele extends Food
{
    /**
     * Act - do whatever the Lele wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Lele() {
        setImage("lele.png");
    }
    
    public void act()
    {
        // Add your action code here.
    }
}
