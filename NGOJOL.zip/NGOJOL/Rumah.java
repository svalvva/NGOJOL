import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Rumah here.
 * 
 * @author (Syalwa Aliya) 
 * @version (1.0)
 * ig : @syalwalyrh
 */
public class Rumah extends Actor
{
    /**
     * Act - do whatever the Rumah wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    public Rumah() {
        setImage("Rumah.png");// Set gambar pemain
        GreenfootImage image = getImage();
        // image.scale(100,100);    // nah yg ini untuk ubah ukuran gambar/ setImage("food.png");
    }
    
    public void act()
    {
        // Add your action code here.
    }
}
